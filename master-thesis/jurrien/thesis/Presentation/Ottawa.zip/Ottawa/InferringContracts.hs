{-# LINE 88 "InferringContracts.lhs" #-}
  {-#  LANGUAGE NoMonomorphismRestriction  #-}
 
  module InferringContracts where
  import Test.QuickCheck
  import Contract
  import Loc
  import Blame
 
  prop_Encode :: [Int] -> Bool
  prop_Sort :: [Int] -> Bool
{-# LINE 204 "InferringContracts.lhs" #-}
  sort = Contract.foldr InferringContracts.insert []
 
  insert x []                   =  [x]
  insert x (y:ys)  | x <= y     =  x:y:ys
                   | otherwise  =  y:InferringContracts.insert x ys
{-# LINE 216 "InferringContracts.lhs" #-}
  sort' = Contract.foldr InferringContracts.insert' []
 
  insert' x []                  =  [x]
  insert' x (y:ys)  | x <= y     =  y:x:ys
                    | otherwise  =  y:InferringContracts.insert' x ys
{-# LINE 228 "InferringContracts.lhs" #-}
  prop_Sort xs = let ys = sort' xs 
                 in isNonDesc ys && (ys `elem` perms xs)
{-# LINE 232 "InferringContracts.lhs" #-}
  perms []      =  [[]]
  perms (x:xs)  =  concatMap (add x) (perms xs)
 
  add x []      =  [[x]]
  add x (y:ys)  =  (x:y:ys):map (y:) (add x ys) 
 
  isNonDesc []        =  True
  isNonDesc [x]       =  True
  isNonDesc (x:y:xs)  =  x<=y && isNonDesc (y:xs)
{-# LINE 247 "InferringContracts.lhs" #-}
  main = do quickCheck prop_Sort
{-# LINE 284 "InferringContracts.lhs" #-}
  sort2 = assert "sort" 
    (Function  (list true)(\xs-> (Prop(\  zs ->  zs `elem` (perms xs) && isNonDesc zs))))
    (fun(\  xs ->  (sort' xs)))
{-# LINE 294 "InferringContracts.lhs" #-}
  blame_Sort = app (sort2) (1) [0,1]
{-# LINE 364 "InferringContracts.lhs" #-}
  encode = merge . map (\z -> (1, z))
 
  merge []                  =  []
  merge [(a,x)]             =  [(a,x)]
  merge ((a,x):(b,y):rest)  =  if x==y
                               then merge ((a+b,x):rest)
                               else (a,x):merge ((b,y):rest)
{-# LINE 378 "InferringContracts.lhs" #-}
  encode' = merge' . map (\z -> (1, z))
 
  merge' []                  =  []
  merge' [(a,x)]             =  [(a,x)]
  merge' ((a,x):(b,y):rest)  =  if x==y
                                then (a+b,x): merge' rest
                                else (a,x): merge' ((b,y):rest)
{-# LINE 392 "InferringContracts.lhs" #-}
  prop_Encode xs =  let ys = encode' xs 
                    in decode ys == xs && noDups (map snd ys) 
{-# LINE 396 "InferringContracts.lhs" #-}
  decode []          =  []
  decode ((n,y):ys)  =  replicate n y ++ decode ys
 
  noDups []        =  True
  noDups [x]       =  True
  noDups (x:y:xs)  =  x/=y && noDups (y:xs)
{-# LINE 408 "InferringContracts.lhs" #-}
  main' = do quickCheck prop_Encode
{-# LINE 444 "InferringContracts.lhs" #-}
  encode2 = assert "encode" 
    (Function  (list true)(\xs-> (Prop(\  zs ->  decode zs == xs && noDups (map snd zs)))))
    (fun(\  xs ->  (encode' xs)))
{-# LINE 454 "InferringContracts.lhs" #-}
  blame_Encode = app (encode2) (1) [2,2,2]
