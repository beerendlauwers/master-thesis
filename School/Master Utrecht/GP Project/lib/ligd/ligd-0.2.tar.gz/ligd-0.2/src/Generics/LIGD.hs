module Generics.LIGD (
  module Generics.LIGD.Base
) where

import Generics.LIGD.Base

