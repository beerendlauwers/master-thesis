
Credits for EMGM
================

This is a list of those who have contributed to the design and development of
Extensible and Modular Generics for the Masses library.

History
-------

The research for EMGM originated with Ralf Hinze. It was extended with work by
Bruno Oliveira and Andres Löh. More details of the library functionality
were explored by Alexey Rodriguez. We are very grateful to all of these people
for the foundation on which this library was built.

Research
--------

*  Ralf Hinze
*  Bruno C. d. S. Oliveira
*  Andres Löh
*  Alexey Rodriguez

Primary Contributors
--------------------

*  Sean Leather
*  José Pedro Magalhães

Current Maintainer
------------------

*  Sean Leather

Other Contributions
-------------------

*  Johan Jeuring
*  Lambert Meertens
*  Larry Evans
*  Antoine Latter (for Ratio)

