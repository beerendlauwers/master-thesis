module Data.Map where
dummy_declaration_in_Data_Map = True
