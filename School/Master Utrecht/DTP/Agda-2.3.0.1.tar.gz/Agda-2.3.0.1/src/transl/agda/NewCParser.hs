{-# OPTIONS -cpp #-}

#define NEWSYNTAX 1

module NewCParser where

#include "CParser.hs"
