
import Distribution.Simple

main = defaultMainWithHooks defaultUserHooks
