module Common.FFI where

data Level = Zero | Suc Level
