module UniversePolymorphicIO where

type AgdaIO a b = IO b
