<a href="/toc.html"><center><img src="/static/cover.png" alt="Learn you an Agda and Achieve Enlightenment!"><br/>Read It!</center></a>
