{-# LANGUAGE UnicodeSyntax #-}
-- Beerend Lauwers
-- 3720942
module Children where

import Child
import SoccerFun.Types
import SoccerFun.Geometry
import SoccerFun.Team
import SoccerFun.Player
import SoccerFun.Field

children ∷ Home → Field → Team
children home field = if home == West then players else mirror field players where

	clubname = "Asynchronous Javascript And XML " ++ show home
	players  = (keeper clubname home field (placeOnField (0.00,0.50)) 1) : 
			   (spits clubname home field (placeOnField (0.60,0.50)) 7) :
	           [child clubname home field (placeOnField pos) nr | (nr,pos) ← zip [2,3,4,5,6,8,9,10,11] playerPositions]

	placeOnField (dx,dy) = Position {px = dx * middleX, py = dy * fwidth field} 
	middleX = flength field / 2.0
	
	playerPositions =
		[(0.20,0.30),
		 (0.20,0.70),
		 (0.23,0.50),
		 (0.50,0.05),
		 (0.50,0.95),
		 (0.70,0.15),
		 (0.70,0.85),
		 (0.90,0.45),
		 (0.90,0.55)
		 ]
