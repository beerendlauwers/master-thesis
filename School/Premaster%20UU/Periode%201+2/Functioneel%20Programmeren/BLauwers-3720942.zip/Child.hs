-- | A very simple minded player, that always chases after the ball and kicks the ball towards the opponent's goal.
module Child where

import SoccerFun.Player
import SoccerFun.Types
import SoccerFun.Geometry
import Control.Monad.State
import SoccerFun.Field
import SoccerFun.Ball
import SoccerFun.RefereeAction
import Debug.Trace
import Data.List


-- Generate a child.

spits :: ClubName -> Home -> Field -> Position -> PlayersNumber -> Player
spits club home field position no = Player
	{playerID = PlayerID {clubName = club, playerNo = no},
	 name     = "child." ++ show no,
	 height   = minHeight,
	 pos      = position,
	 nose     = 0,
	 speed    = 0,
	 skills   = (Running, Kicking, Rotating),
	 effect   = Nothing,
	 stamina  = maxStamina,
	 health   = maxHealth,
	 -- The only thing the child remembers is on which side it belongs to
	 brain    = Brain {m = Memory {myHome = home}, ai = defaultbrain field}}

child :: ClubName -> Home -> Field -> Position -> PlayersNumber -> Player
child club home field position no = Player
	{playerID = PlayerID {clubName = club, playerNo = no},
	 name     = "child." ++ show no,
	 height   = minHeight,
	 pos      = position,
	 nose     = 0,
	 speed    = 0,
	 skills   = (Running, Kicking, Rotating),
	 effect   = Nothing,
	 stamina  = maxStamina,
	 health   = maxHealth,
	 -- The only thing the child remembers is on which side it belongs to
	 brain    = Brain {m = Memory {myHome = home}, ai = minibrain field}}
	 
keeper :: ClubName -> Home -> Field -> Position -> PlayersNumber -> Player
keeper club home field position no = Player
	{playerID = PlayerID {clubName = club, playerNo = no},
	 name     = "child." ++ show no,
	 height   = minHeight,
	 pos      = position,
	 nose     = 0,
	 speed    = 0,
	 skills   = (Running, Kicking, Rotating),
	 effect   = Nothing,
	 stamina  = maxStamina,
	 health   = maxHealth,
	 -- The only thing the child remembers is on which side it belongs to
	 brain    = Brain {m = Memory {myHome = home}, ai = keeperbrain field}}

-- The child remembers nothing but which side it is playing on.
data Memory = Memory {myHome :: Home}

-- A stateful computation, with the memory serving as a state.
type Think = State Memory

-- Shared Functions
halt :: Think PlayerAction
halt = move 0 0

-- run towards a position
runTowards :: Player -> Position -> Metre -> Think PlayerAction
runTowards player point eps = let
		distance = dist            (pos player) point
		angle    = angleWithObject (pos player) point
		v        = max 6.0 distance
	in if (distance <= eps)
		then halt
		else move Speed {direction=angle,velocity=v} (angle - (nose player))
			
move :: Speed -> Angle -> Think PlayerAction
move speed angle = return $ Move speed angle

track :: Player -> Position -> Metre -> Think PlayerAction
track p position eps = runTowards p position eps

centerOfGoal :: Home -> Field -> Position
centerOfGoal home field = Position
	{py = let (n,s) = goalPoles field in (n+s)/2,
	 px = if home == West then 0 else flength field}

-- | Based on the perceived surroundings (BrainInput) and the memories, make a decision (BrainOutput) and update the memory.
defaultbrain :: Field -> PlayerAI Memory
--        = Field -> BrainInput -> Think PlayerAction
defaultbrain field BrainInput {referee=refereeActions, me=me, ball=ballState, others=others} = do
	mem <- get
	let home = myHome mem
	when (any isEndHalf refereeActions) (put mem {myHome = other home})
	if ballIsCloseTo me
		then let goal = centerOfGoal (other home) field in me `kick` goal
		else track me ballXY (maxKickReach me)
	
	where
	ball = getBall ballState (me:others) :: Ball
	ballXY = pxy $ ballPos ball :: Position
	ballIsCloseTo p = dist (pos p) ballXY < maxKickReach p
	
	kick :: Player -> Position -> Think PlayerAction
	kick p point = let
		angle = angleWithObject (pos p) point
		v = 2.0*dist (pos p) point
		in if (dist (pos p) (ballPos ball) <= maxKickReach p)
			then return $ KickBall Speed3D {vxy = Speed {direction=angle,velocity=v},vz=1.0}
			else halt

-- | Based on the perceived surroundings (BrainInput) and the memories, make a decision (BrainOutput) and update the memory.
minibrain :: Field -> PlayerAI Memory
--        = Field -> BrainInput -> Think PlayerAction
minibrain field BrainInput {referee=refereeActions, me=me, ball=ballState, others=others} = do
	mem <- get
	let home = myHome mem
	when (any isEndHalf refereeActions) (put mem {myHome = other home})
	
	-- A list of your teammates and how interesting it is to pass to them.
	let teammateList = sortBy sortPlayer (map (\p -> clogFactor p (other home) field) myTeam)
	let goodPass = snd (head teammateList)

	-- A list of how close each player is to the ball. Determines their movements.
	let distanceList = sortBy sortPlayer (map getDistanceFromBall (me:myTeam))
	let leader = snd (head distanceList)
	let coleader1 = snd (distanceList !! 1)
	let coleader2 = snd (distanceList !! 2)
	let defender1 = snd (distanceList !! 3)
	let defender2 = snd (distanceList !! 4)
	let defender3 = snd (distanceList !! 5)
	let defender4 = snd (distanceList !! 6)
	
	-- We use this list to see if the current player is closest to the goal.
	let goalDistance = sortBy sortPlayer (map (\p -> playerDistanceFromGoal p (other home) field) (me:myTeam))
	let closestToGoal = snd (head goalDistance)
	
	let maxDistance = 40 -- Hover between max and min
	let minDistance = 20
	let minminDistance = 500 -- Pay attention to the ball from this distance
	
	-- Check if current player is nearby another player
	let nearby player = (distanceFromMe player) > maxDistance || (distanceFromMe player) < minDistance
	
	-- Some logic for kicking the ball.
	let checkPass = if ballIsCloseTo me then if (closestToGoal == me || fst (head teammateList) > 5000) then kick (centerOfGoal (other home) field) else kick (pos goodPass) else track me ballXY (maxKickReach me)
	
	-- Some logic for running towards a player.
	let trackNearby player x y = track player (offset (other home) (pos player) minDistance y) minminDistance
	
	-- The main concept of this AI was that you would have the "leader" who has control over the ball.
	-- In a certain range of the leader are 2 co-leaders, which in turn are surrounded by defenders.
	-- This works reasonably well, but it seems I did not quite understand how (often) players are refreshed:
	-- Sometimes, a player that *should* have become the leader does not, and others appear to be "stuck" in their
	-- behavior as well. I also didn't know about the notion of "offside", so this AI fails there.
	-- If you let it replay a few times, you'll notice the AI does give some pretty good passes due to my weighted selection heuristic.
	if (leader == me)
	    then checkPass
		else if (coleader1 == me || coleader2 == me)
				then if nearby leader
						then trackNearby leader minDistance 0
						else checkPass
				else if (defender1 == me || defender2 == me)
					then if defender1 == me
							then if nearby coleader1
									then trackNearby coleader1 minDistance 0
									else checkPass
							else if nearby coleader2
									then trackNearby coleader2 minDistance 0
									else checkPass
					else if (defender3 == me || defender4 == me)
							then if defender3 == me
									then if nearby defender1
											then trackNearby defender1 minDistance 0
											else checkPass
									else if nearby defender2
											then trackNearby defender1 minDistance 0
											else checkPass
							else trackNearby defender2 minDistance 0
	where
	
	-- Used for offsetting position coordinates of players
	offset :: Home -> Position -> XPos -> YPos -> Position
	offset h (Position px py) x y = if h == West then (Position (px-x) (py+y)) else (Position (px+x) (py+y))
	offsetY (Position px py) field = dist (Position px py) (Position px ((fwidth field) / 2))
	
	ball = getBall ballState (me : others) :: Ball
	ballXY = pxy $ ballPos ball :: Position
	ballIsCloseTo p = dist (pos p) ballXY < maxKickReach p

	kick :: Position -> Think PlayerAction
	kick point = let
			angle = angleWithObject (pos me) point
			v = 2.0*dist (pos me) point
		in if (dist (pos me) (ballPos ball) <= maxKickReach me)
			then return $ KickBall Speed3D {vxy = Speed {direction=angle,velocity=v},vz=1.0}
			else halt

	otherTeam = filter (\x -> not (sameClub x me)) others :: [Player]
	myTeam = filter (\x -> sameClub x me) others :: [Player]
	
	playerDistanceFromGoal :: Player -> Home -> Field -> (Float, Player)
	playerDistanceFromGoal x o f = (distanceFromGoal x o f, x)
	distanceFromGoal x otherHome field = dist (centerOfGoal otherHome field) (pos x)
	
	getDistanceFromBall :: Player -> (Float, Player)
	getDistanceFromBall p = (dist ballXY (pos p), p)
	
	-- This code determines what players are good options to pass the ball towards.
	goodPositionFromMe x = if distanceFromMe x < 10 then 5000 else distanceFromMe x
	distanceFromMe x = dist (pos me) (pos x) :: Float
	distanceFrom x y = dist (pos x) (pos y) :: Float
	
	-- Calculates how dangerous an opponent is based on his distance.
	calculateDanger :: Float -> Float
	calculateDanger x = (3000.0 * 0.85^^ceiling x)
	
	-- Calculates how "Clogged" a player is. Uses 3 variables:
	-- 1. player distance from goal, squared (because it's important)
	-- 2. player distance from current player, squared (also very important)
	-- 3. all calculated dangers from all enemy players.
	-- Play around with this to adjust for odd behaviour.
	clogFactor :: Player -> Home -> Field -> (Float, Player)
	clogFactor x o f = ( ((distanceFromGoal x o f)^2) + ((goodPositionFromMe x)^2)
	                         + foldr (+) 0 (map (\p -> calculateDanger (distanceFrom me p)) otherTeam), x)

	sortPlayer (x1,y1) (x2,y2) = compare x1 x2
            
-- | Based on the perceived surroundings (BrainInput) and the memories, make a decision (BrainOutput) and update the memory.
keeperbrain :: Field -> PlayerAI Memory
--        = Field -> BrainInput -> Think PlayerAction
keeperbrain field BrainInput {referee=refereeActions, me=me, ball=ballState, others=others} = do
	mem <- get
	let home = myHome mem
	when (any isEndHalf refereeActions) (put mem {myHome = other home})
	if (ballIsWithinRangeOf 10) == True && (closeToGoal me (centerOfGoal home field)) == True
	    then if ballIsCloseTo me
		        then let goal = centerOfGoal (other home) field in me `kick` goal
                else track me ballXY (maxKickReach me)
		else runTowards me (centerOfGoal home field) (maxKickReach me)
	where
	ball = getBall ballState (me : others) :: Ball
	ballXY = pxy $ ballPos ball :: Position
	ballIsCloseTo p = dist (pos p) ballXY < maxKickReach p
	ballIsWithinRangeOf x = dist (pos me) ballXY < x
	
	kick :: Player -> Position -> Think PlayerAction
	kick p point = let
		angle = angleWithObject (pos p) point
		v = 2.0*dist (pos p) point
		in if (dist (pos p) (ballPos ball) <= maxKickReach p)
			then return $ KickBall Speed3D {vxy = Speed {direction=angle,velocity=v},vz=1.0}
			else halt

	closeToGoal :: Player -> Position -> Bool
	closeToGoal p goal = if (dist (pos p) goal) < 10 then True else False
